﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Client client = new Client();

            client.output();
            Console.ReadKey();
        }
    }
 
  
    class Client
    {
        private StringBuilder outputString;
        private Facade packageA, packageB, packageC;
        public Client()
        {
            packageA = new PackageA();
            packageB = new PackageB();
            packageC = new PackageC();
            outputString = new StringBuilder();
        }
        private void makePackageA()
        {
            outputString.Append(packageA.doSomething());
        }
        private void makePackageB()
        {
            outputString.Append(packageB.doSomething());
        }
        private void makePackageC()
        {
            outputString.Append(packageC.doSomething());
        }
        public void output()
        {
         
            Console.WriteLine(outputString);
        }
    }
    interface Facade
    {
        string doSomething();
    }
    class PackageA : Facade
    {
        public string doSomething()
        {
            return ("PackageA");
        }
    }
    class PackageB : Facade
    {
        public string doSomething()
        {
            return ("PackageB");
        }
    }
    class PackageC : Facade
    {
        public string doSomething()
        {
            return ("PackageC") ;
        }
    }


}
