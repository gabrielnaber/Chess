﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype
{
    class Program
    {
        //Prototype Pattern
        /// <summary>
        /// löst das Problem der Duplizierung
        /// Verwendung:
        ///     Wenn ein Objekt kopiert werden soll,
        ///     und dabei nicht das orginale Objekt verändert werden soll
        /// Prototype Pattern klont dein originales Objekt
        /// 
        /// </summary>
        static void Main(string[] args)
        {
            PermanentEmployee permanentEmployee = new PermanentEmployee();
            permanentEmployee.Name = "Sam";
            permanentEmployee.Age = 25;
            permanentEmployee.EmployeeType = "Permanent";

            PermanentEmployee permanentEmployeeClone = (PermanentEmployee)permanentEmployee.ShallowClone();
            permanentEmployeeClone.Name = "Tom";
            permanentEmployeeClone.Age = 30;

            Console.WriteLine(permanentEmployee);
            Console.WriteLine(permanentEmployeeClone);

            Console.ReadKey();
        }
    }
    interface IEmployee
    {
        IEmployee ShallowClone();
        IEmployee DeepClone();
       
    }
    abstract class AEmployee : IEmployee
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string EmployeeType { get; set; }
        public virtual IEmployee ShallowClone()
        {
            //Shallow Clone
            //klont nur Properties
            return this.MemberwiseClone() as IEmployee;
        }
        public virtual IEmployee DeepClone()
        {
            //Deep Clone
            //klont das Objekt
            return this.MemberwiseClone() as IEmployee;
        }

        public override string ToString()
        {
            return Name + " " + Age + " " + EmployeeType;
        }

        public object Clone()
        {
            return DeepClone();
        }
    }
    class PermanentEmployee : AEmployee { }
    class TemporaryEmployee : AEmployee { }

}
