﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class Program
    {
        //Singleton Pattern
            /// <summary>
            /// Wenn ein System nur eine Instanz benötigt 
            /// stellt einen globalen Zugriffspunkt zur Verfügung
            /// Instanzierung durch den Client muss verhindert werden
            /// 
            /// Verwendung:
            ///     einmalige und zustandslose Strukturen (Factorys, Utilityklassen)
            ///     schnell und unkompliziert
            /// 
            /// Vorteile:
            ///     + Zugriffskontrolle
            ///     + Lazy-Loading (erst erzeugt, wenn es benötigt wird)
            /// Nachteile
            ///     - globale Verfügbarkeit
            ///     - Intransparenz
            /// </summary>

        static void Main(string[] args)
        {
            Console.WriteLine( Singleton.Instance.ToString());
            Console.ReadKey();
        }
        class Singleton
        {
            private static Singleton instance = null;
            private string Name { get;set;}

            private static object lockThis = new object();

            private Singleton()
            {
                Console.WriteLine("Singleton Instance");

                Name = "Test";
            }

            public static Singleton Instance
            {
                get
                {
                    //lock stellt sicher, dass ein Codeabschnitt 
                    //nicht gleichzeitig von mehreren Threads ausgeführt werden kann
                    //Der nächste Thread wartet vor dem lock Block
                    lock (lockThis)
                    {
                        if (instance == null)
                            instance = new Singleton();
                        return instance;
                    }
                }
            }
            public override string ToString()
            {
                return Name;
            }
        }
    }
}
