﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter_Pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IScrew screw = new Torx_Headed_Screw();
            ScrewDriver screwdriver = new ScrewDriver();

            screwdriver.screw(screw, "up");

            Console.ReadKey();
        }
    }
    interface IScrewdriver
    {
        void screw(IScrew screws, string direction);
    }
    interface IScrew
    {
        void screwDown();

        void screwUp();
    }
    class Torx_Headed_Screw : IScrew
    {
        public void screwDown()
        {
            Console.Write("Torx : screwDown");
        }

        public void screwUp()
        {
            Console.Write("Torx : screwUp");
        }
    }
    class Cross_Headed_Screw : IScrew
    {
        public void screwDown()
        {
            Console.Write("Cross : screwDown");
        }

        public void screwUp()
        {
            Console.Write("Torx : screwUp");
        }
    }
    class Adapter : IScrewdriver
    {
        IScrew screws;

        public Adapter(IScrew screw)
        {

            if(screw.GetType() == typeof(Cross_Headed_Screw))
            {
                screws = new Cross_Headed_Screw();
            }
            else if(screw.GetType() == typeof(Torx_Headed_Screw))
            {
                screws = new Torx_Headed_Screw();
            }
            
        }
        public void screw(IScrew screws, string direction)
        {
            if (direction.ToLower() == "up")
            {
                screws.screwUp();
            }
            if(direction.ToLower() == "down")
            {
                screws.screwDown();
            }
        }

        
    }
    class ScrewDriver : IScrewdriver
    {
        Adapter adapter;
        public void screw(IScrew screw, string direction)
        {
            adapter = new Adapter(screw);
            adapter.screw(screw, direction);
        }
    }


}
