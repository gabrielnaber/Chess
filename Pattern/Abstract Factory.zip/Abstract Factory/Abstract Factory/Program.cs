﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory
{
    class Program
    {
        static void Main(string[] args)
        {
             AbstractFactory factoryAmsterdam = new KonkreteFactoryAmsterdam();
            Captain client1 = new Captain(factoryAmsterdam);
            client1.Run();

            AbstractFactory factoryDeutschland = new KonkreteFactoryDeutschland();
            Captain white = new Captain(factoryDeutschland);
            white.Run();

            Console.ReadKey();
        }
    }
    abstract class AbstractFactory
    {
        public abstract AbstractShip CreateBoat();
        public abstract AbstractBoat CreateShip();
    }


    class KonkreteFactoryAmsterdam : AbstractFactory
    {
        public override AbstractShip CreateBoat()
        {
            return new Ship1();
        }
        public override AbstractBoat CreateShip()
        {
            return new Boat1();
        }
    }

    class KonkreteFactoryDeutschland : AbstractFactory
    {
        public override AbstractShip CreateBoat()
        {
            return new Ship2();
        }
        public override AbstractBoat CreateShip()
        {
            return new Boat2();
        }
    }


    abstract class AbstractShip
    {

    }


    abstract class AbstractBoat
    {
        public abstract void factoryMethod(AbstractShip a);
    }


    class Ship1 : AbstractShip
    {

    }


    class Boat1 : AbstractBoat
    {
        public override void factoryMethod(AbstractShip a)
        {
            Console.WriteLine(this.GetType().Name +
              " und " + a.GetType().Name);
        }
    }


    class Ship2 : AbstractShip
    {
    }


    class Boat2 : AbstractBoat
    {
        public override void factoryMethod(AbstractShip a)
        {
            Console.WriteLine(this.GetType().Name +
              " und " + a.GetType().Name);
        }
    }

    class Captain
    {
        private AbstractShip _abstractShip1;
        private AbstractBoat _abstractBoat1;

        public Captain(AbstractFactory factory)
        {
            _abstractBoat1 = factory.CreateShip();
            _abstractShip1 = factory.CreateBoat();
        }

        public void Run()
        {
            _abstractBoat1.factoryMethod(_abstractShip1);
        }
    }
}

