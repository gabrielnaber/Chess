﻿using System;

namespace DoFactory.GangOfFour.Mediator.Structural
{
    class Program
    {
        static void Main()
        {
            Mediator m = new KonkretesMediator();
           

            Kolleg krems = new KollegStPoelten(m);
            Kolleg stpoelten = new KollegKrems(m);

            krems.Send("Schüleranzahl 100");
            stpoelten.Send("Schüleranzahl 250");

            Console.ReadKey();
        }
    }
    interface Mediator
    {
        void Send(string message, Kolleg colleague);
    }
    class KonkretesMediator : Mediator
    {
        public void Send(string message, Kolleg kolleg)
        {
            kolleg.Notify(message);
        }
    }
    interface Kolleg
    {
        void Send(string message);
        void Notify(string message);
    }

    class KollegStPoelten : Kolleg
    {
        private Mediator mediator;
        public KollegStPoelten(Mediator mediator)
        {
            this.mediator = mediator;
        }
        
        public void Send(string message)
        {
            mediator.Send(message, this);
        }

        public void Notify(string message)
        {
            Console.WriteLine("St.Pölten hat die Nachricht erhalten: " + message);
        }
    }

    class KollegKrems : Kolleg
    {
        private Mediator mediator;

        public KollegKrems(Mediator mediator)
        {
            this.mediator = mediator;
        }
        public void Send(string message)
        {
            mediator.Send(message, this);
        }

        public void Notify(string message)
        {
            Console.WriteLine("Krems hat die Nachricht erhalten: " + message);
        }
    }
}