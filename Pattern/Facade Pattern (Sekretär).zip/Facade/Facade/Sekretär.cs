﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Facade.Komponenten;
using Facade.Command;
using Facade;

namespace Facade
{
    class Sekretär
    {
        public void schreibeVersende(string text)
        {
            Computer computer = new Computer();
            ICommand command;
            Textverarbeitungsprogramm textverarbeitungsprogramm = new Textverarbeitungsprogramm();
            Drucker drucker = new Drucker();

            command = new OnCommand(computer);
            command.execute();

            textverarbeitungsprogramm.open();
            Document document = textverarbeitungsprogramm.getDocument(text);
            textverarbeitungsprogramm.close();
            command = new OnCommand(drucker);
            command.execute();
            drucker.configure();
            drucker.fillPapercase();
            computer.drucke(document);
            command = new OffCommand(drucker);
            command.execute();
            command = new OffCommand(computer);
            command.execute();

            Stift stift = new Stift();
            stift.action(document);

            Stempel stempel = new Stempel();
            stempel.action(document);

            Briefmarkenautomat briefmarkenautomat = new Briefmarkenautomat();
            briefmarkenautomat.action(document);

            Briefkasten briefkasten = new Briefkasten();
            briefkasten.action(document);

        }
    }
}
