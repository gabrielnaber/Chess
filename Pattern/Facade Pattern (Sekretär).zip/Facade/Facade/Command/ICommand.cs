﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Command
{
    interface ICommand
    {
        void execute();
    }
    class OnCommand : ICommand
    {
        private ICommandable commandable;

        public OnCommand(ICommandable commandable)
        {
            this.commandable = commandable;
        }
        public void execute()
        {
            commandable.on();
        }
    }
    class OffCommand : ICommand
    {
        private ICommandable commandable;

        public OffCommand(ICommandable commandable)
        {
            this.commandable = commandable;
        }
        public void execute()
        {
            commandable.off();
        }
    }
}
