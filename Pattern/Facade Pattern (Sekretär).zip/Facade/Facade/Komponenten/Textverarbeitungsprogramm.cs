﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Komponenten
{
    class Textverarbeitungsprogramm
    {
        public Document getDocument(string s)
        {
            Document document = new Document();
            document.Text = s;
            Console.WriteLine("Dokument "+ document + "wird verarbeitet.");

            return document;
        }
        public void open()
        {
            Console.WriteLine("Dokument wird geöffnet.");
        }
        public void close()
        {
            Console.WriteLine("Dokument wird geschlossen.");
        }
    }
}
