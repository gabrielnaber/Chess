﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Komponenten
{
    class Briefmarkenautomat : IKomponenten
    {
        public void action(Document document)
        {
            Console.WriteLine("Dokument " + document.Text + " wird frankiert.");
        }
    }
}
