﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Facade.Command;

namespace Facade.Komponenten
{
    class Computer :  ICommandable
    {
        public void drucke(Document document)
        {
            Console.WriteLine("Dokument " + document + "wird gedruckt.");
        }
        public void on() {
            Console.WriteLine("Computer ist eingeschaltet!");
        }
        public void off() {
            Console.WriteLine("Computer ist ausgeschaltet!");
        }
    }
}
