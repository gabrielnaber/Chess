﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Facade.Command;

namespace Facade.Komponenten
{
    class Drucker :  ICommandable
    {
        
        public void configure()
        {
            Console.WriteLine("Drucker wird konfiguriert.");
        }
        public void fillPapercase()
        {
            Console.WriteLine("Drucker wird mit Papier nachgefüllt.");
        }

        public void off()
        {
            Console.WriteLine("Drucker ist ausgeschaltet.");
        }

        public void on()
        {
            Console.WriteLine("Drucker ist eingeschaltet.");
        }
    }
}
