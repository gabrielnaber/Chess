﻿using System;
using System.Windows;
using System.Windows.Media;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Threading;

namespace Schach
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();
            Settings settings = new Settings();
            settings.configure(_myviewport);

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            
           MessageBoxResult result =  MessageBox.Show("Spiel beenden?", "", MessageBoxButton.YesNo);

            if(result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

    }
}
