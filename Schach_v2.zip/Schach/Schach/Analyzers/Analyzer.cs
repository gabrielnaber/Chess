﻿using System;
using System.Collections.Generic;
using System.Windows.Media.Media3D;
using Schach.MoveOptions;

namespace Schach
{
    public interface IAnalyzer
    {
        IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyzer);
    }
    public interface IAnalyzeType
    {
        IBuildAnalyzer Analyze(IModel source, IModel target);
    }
    public class AnalyzeDefault : IAnalyzeType
    {
        public IBuildAnalyzer Analyze(IModel sourceModel, IModel targetModel)
        {
            
            if(sourceModel.GetType() == typeof(Figure) && sourceModel.Color != targetModel.Color)
            {
              
                return new BuildThrowAnalyzer();
            }
            else if (!sourceModel.Occupied && sourceModel.GetType() == typeof(Tile))
            {
                
                return new BuildStayAnalyzer();
            }
            return new BuildNullAnalyzer();
                
        }
    }

    public class AnalyzerFarmer : IAnalyzer
    {
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {

            IMoveOptions Moving1 = new MoveFarmer();
            IMoveOptions Moving2 = new MoveFarmerThrow();
            if (buildanalyze.GetType() == typeof(BuildStayAnalyzer) && Moving1.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
            {
                return new MovementStay();
            }
            else if (buildanalyze.GetType() == typeof(BuildThrowAnalyzer) && Moving2.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
            {
                return new MovementThrow();
            }
            else return new MovementNull();
           
        }
    }
    public class AnalyzerTower : IAnalyzer
    {
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {
            IMoveOptions Moving = new MoveTower();
           
            IAnalyzeOnBlockingFigure Figure = new AnalyzerTowerBlocking();
            bool blocked = Figure.isBlocking(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name);
            IAnalyzeOnBlockingFigure f = new AnalyzerTowerBlockingY();
            bool blocked1 = f.isBlocking(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name);
            if (!blocked && !blocked1)
            {
                if (buildanalyze.GetType() == typeof(BuildThrowAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
                {
                    return new MovementThrow();
                }
                else if (buildanalyze.GetType() == typeof(BuildStayAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
                {
                    return new MovementStay();
                }
            }
            return new MovementNull();
        }
    }
    public class AnalyzerRunner : IAnalyzer
    {
        
           
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {
            IMoveOptions Moving = new MoveRunner();

            IAnalyzeOnBlockingFigure figure = new AnalyzerOnBlockingFigureAxisYX();

            bool blocked = figure.isBlocking(targetOffsetX, targetOffsetY,  sourceOffsetX,  sourceOffsetY,  name);

            if (!blocked)
            {
                if (buildanalyze.GetType() == typeof(BuildThrowAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
                {
                    return new MovementThrow();
                }
                else if (buildanalyze.GetType() == typeof(BuildStayAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
                {
                    return new MovementStay();
                }
            }
            return new MovementNull();
        }
    }
    public class AnalyzeHorse : IAnalyzer
    {
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {
            IMoveOptions Moving = new MoveHorse();
            if (buildanalyze.GetType() == typeof(BuildThrowAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
            {
                return new MovementThrow();
            }
            else if (buildanalyze.GetType() == typeof(BuildStayAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
            {
                return new MovementStay();
            }
            else return new MovementNull();
        }
    }
    public class AnalyzerQueen : IAnalyzer
    {
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {

            IMoveOptions Moving = new MoveQueen();

            IAnalyzeOnBlockingFigure figure = new AnalyzerOnBlockingFigureAxisYX();

            bool blocked3 = figure.isBlocking(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name);

            IAnalyzeOnBlockingFigure Figure = new AnalyzerTowerBlocking();
            bool blocked = Figure.isBlocking(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name);
            IAnalyzeOnBlockingFigure f = new AnalyzerTowerBlockingY();
            bool blocked1 = f.isBlocking(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name);

            if (!blocked && !blocked1 && !blocked3)
            {
                if (buildanalyze.GetType() == typeof(BuildThrowAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
                {
                    return new MovementThrow();
                }
                else if (buildanalyze.GetType() == typeof(BuildStayAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
                {
                    return new MovementStay();
                }
            }

            return new MovementNull();
        }
    }
    public class AnalyzerKing : IAnalyzer
    {
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {
            IMoveOptions Moving = new MoveKing();
            if (buildanalyze.GetType() == typeof(BuildThrowAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
            {
                return new MovementThrow();
            }
            else if (buildanalyze.GetType() == typeof(BuildStayAnalyzer) && Moving.isPossible(targetOffsetX, targetOffsetY, sourceOffsetX, sourceOffsetY, name))
            {
                return new MovementStay();
            }
            else return new MovementNull();
        }
    }
    public class AnalyzerNull : IAnalyzer
    {
        public IMovementCommand Analyze(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name, IBuildAnalyzer buildanalyze)
        {
            return new MovementNull();
        }
    }
}
