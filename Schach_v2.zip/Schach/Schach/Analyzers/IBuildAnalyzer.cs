﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schach
{
   public interface IBuildAnalyzer
    {
        List<IAnalyzer> build();
    }
    public class BuildThrowAnalyzer : IBuildAnalyzer
    {
        List<IAnalyzer> analyzers = new List<IAnalyzer>();

        public List<IAnalyzer> build()
        {
            analyzers.Add(new AnalyzerFarmer());
            analyzers.Add(new AnalyzerKing());
            analyzers.Add(new AnalyzerRunner());
            analyzers.Add(new AnalyzerQueen());
            analyzers.Add(new AnalyzerTower());
            analyzers.Add(new AnalyzeHorse());

            return analyzers;
        }
    }
    public class BuildStayAnalyzer : IBuildAnalyzer
    {
        List<IAnalyzer> analyzers = new List<IAnalyzer>();

        public List<IAnalyzer> build()
        {
            analyzers.Add(new AnalyzerFarmer());
            analyzers.Add(new AnalyzerKing());
            analyzers.Add(new AnalyzerRunner());
            analyzers.Add(new AnalyzerQueen());
            analyzers.Add(new AnalyzerTower());
            analyzers.Add(new AnalyzeHorse());

            return analyzers;
        }
    }
    public class BuildNullAnalyzer : IBuildAnalyzer
    {
        List<IAnalyzer> analyzers = new List<IAnalyzer>();
        public List<IAnalyzer> build()
        {
            analyzers.Add(new AnalyzerNull());

            return analyzers;
        }
    }
}
