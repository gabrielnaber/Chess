﻿using HelixToolkit.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Media3D;

namespace Schach
{
    interface IAnalyzeOnBlockingFigure
    {
        bool isBlocking(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name);
    }
    public class AnalyzerTowerBlocking : IAnalyzeOnBlockingFigure
    {
        List<IModel> models = Synchronize.models;
        public bool isBlocking(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            List<IModel> m = new List<IModel>();

            if (sourceOffsetY == targetOffsetY)
            {
                foreach (IModel item in models)
                {
                    Matrix3D tt = item.getElement().Transform.Value;

                    if (tt.OffsetY == sourceOffsetY && item.Name == "Figure")
                    {
                        m.Add(item);
                    }
                }
                if (sourceOffsetX > targetOffsetX)
                {
                    foreach (IModel itme in m)
                    {
                        Matrix3D s = itme.getElement().Transform.Value;
                        if (s.OffsetX < sourceOffsetX && s.OffsetX > targetOffsetX)
                        {
                            return true;
                        }
                    }
                }
                if (sourceOffsetX < targetOffsetX)
                {
                    foreach (IModel itme in m)
                    {
                        Matrix3D s = itme.getElement().Transform.Value;
                        if (s.OffsetX > sourceOffsetX && s.OffsetX < targetOffsetX)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;

        }

       
    }
    public class AnalyzerTowerBlockingY : IAnalyzeOnBlockingFigure
    {
        List<IModel> models = Synchronize.models;
        public bool isBlocking(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            List<IModel> m = new List<IModel>();
            if (targetOffsetX == sourceOffsetX)
            {
                foreach (IModel item in models)
                {
                    Matrix3D tt = item.getElement().Transform.Value;

                    if (tt.OffsetX == sourceOffsetX && item.Name == "Figure")
                    {
                        m.Add(item);
                    }
                }
                if (sourceOffsetY > targetOffsetY)
                {
                    foreach (IModel itme in m)
                    {
                        Matrix3D s = itme.getElement().Transform.Value;
                        if (s.OffsetY < sourceOffsetY && s.OffsetY > targetOffsetY)
                        {
                            return true;
                        }
                    }
                }
                if (sourceOffsetY < targetOffsetY)
                {
                    foreach (IModel itme in m)
                    {
                        Matrix3D s = itme.getElement().Transform.Value;
                        if (s.OffsetY > sourceOffsetY && s.OffsetY < targetOffsetY)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

    }
    public class AnalyzerOnBlockingFigureAxisYX : IAnalyzeOnBlockingFigure
    {
        List<IModel> models = Synchronize.models;
        public bool isBlocking(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            List<IModel> m = new List<IModel>();
            double count = targetOffsetY;
           // MessageBox.Show("" + targetOffsetX + " " + targetOffsetY);

            if (targetOffsetY < sourceOffsetY)
            {
                for (double i = targetOffsetX; i > sourceOffsetX; i--)
                {
                    foreach (IModel item in models)
                    {
                        Matrix3D tt = item.getElement().Transform.Value;


                        if (tt.OffsetX == (i) && tt.OffsetY == count && item.Name == "Figure" && item.getElement().GetName() != name)
                        {
                          //  MessageBox.Show(" " + tt.OffsetX + " " + tt.OffsetY);
                            return true;
                        }

                    }
                    count++;
                }
                count = targetOffsetY;
                for (double i = targetOffsetX; i < sourceOffsetX; i++)
                {
                    foreach (IModel item in models)
                    {
                        Matrix3D tt = item.getElement().Transform.Value;


                        if (tt.OffsetX == (i) && tt.OffsetY == count && item.Name == "Figure" && item.getElement().GetName() != name)
                        {
                            //MessageBox.Show(" " + tt.OffsetX + " " + tt.OffsetY);
                            return true;
                        }

                    }
                    count++;
                }


            }
            count = targetOffsetY;
            if(targetOffsetY > sourceOffsetY)
            {
                for (double i = targetOffsetX; i > sourceOffsetX; i--)
                {
                    foreach (IModel item in models)
                    {
                        Matrix3D tt = item.getElement().Transform.Value;


                        if (tt.OffsetX == (i) && tt.OffsetY == count && item.Name == "Figure" && item.getElement().GetName() != name)
                        {
                          //  MessageBox.Show(" " + tt.OffsetX + " " + tt.OffsetY);
                            return true;
                        }

                    }
                    count--;
                }
                count = targetOffsetY;
                for (double i = targetOffsetX; i < sourceOffsetX; i++)
                {
                    foreach (IModel item in models)
                    {
                        Matrix3D tt = item.getElement().Transform.Value;


                        if (tt.OffsetX == (i) && tt.OffsetY == count && item.Name == "Figure" && item.getElement().GetName() != name)
                        {
                          //  MessageBox.Show(" " + tt.OffsetX + " " + tt.OffsetY);
                            return true;
                        }

                    }
                    count--;
                }


            }



            return false;
        }
    }
}
