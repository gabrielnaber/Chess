﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;

namespace Schach
{
    static class Synchronize
    {
        static public List<IModel> models = new List<IModel>();

        static public HelixViewport3D myviewport = new HelixViewport3D();

        static public void syncGame(IModel m)
        {
            myviewport.Children.Remove(m.getElement());
            models.Remove(m);
        }
        static public void syncCamera(PerspectiveCamera camera)
        {
            myviewport.Camera = camera;
        }
    }
}
