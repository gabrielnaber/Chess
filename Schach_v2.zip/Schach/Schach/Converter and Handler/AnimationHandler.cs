﻿using System;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;
using static System.Convert;
using static System.TimeSpan;

namespace Schach
{
     public  class AnimationHandler
    {

        public void AnimateFigure(ModelUIElement3D target, ModelUIElement3D source)
        {
            Matrix3D t = target.Transform.Value;
            Matrix3D s = source.Transform.Value;

            int tx = ToInt32(t.OffsetX);
            int ty = ToInt32(t.OffsetY);


            int sx = ToInt32(s.OffsetX);
            int sy = ToInt32(s.OffsetY);

            DoubleAnimation xAnimation =
            new DoubleAnimation(tx, sx, FromMilliseconds(1500));
            DoubleAnimation yAnimation =
            new DoubleAnimation(ty, sy, FromMilliseconds(1500));
            DoubleAnimation zAnimation =
            new DoubleAnimation(0, 120, FromMilliseconds(750));
            xAnimation.Completed += new EventHandler(animation_completed);
            target.Transform.BeginAnimation(TranslateTransform3D.OffsetXProperty, xAnimation);
            target.Transform.BeginAnimation(TranslateTransform3D.OffsetYProperty, yAnimation);
            zAnimation.AutoReverse = true;
            target.Transform.BeginAnimation(TranslateTransform3D.OffsetZProperty, zAnimation);

            
        }
        public void AnimateCamera(PerspectiveCamera CameraT, PerspectiveCamera CameraS)
        {
            Matrix3D s = CameraS.Transform.Value;
            Matrix3D t = CameraT.Transform.Value;

            int tx = ToInt32(t.OffsetX);
            int ty = ToInt32(t.OffsetY);


            int sx = ToInt32(s.OffsetX);
            int sy = ToInt32(s.OffsetY);

            DoubleAnimation xAnimation =
           new DoubleAnimation(tx, sx, FromMilliseconds(10000));
            DoubleAnimation yAnimation =
            new DoubleAnimation(ty, sy, FromMilliseconds(1500));

        }
        public void animation_completed(object sender, EventArgs e)
        {
            Moving.player = Moving.player.nextPlayer();
        }
       
    }
}
