﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace Schach
{
    public class ModelConverter
    {
        private List<IModel> models = Synchronize.models;

        public IModel order(ModelUIElement3D source)
        {
            IModel itle = new Tile();
            IModel Figure = new Figure();

            foreach (IModel i in models)
            {
                if (i.getElement() == source)
                {
                    return i;
                }
            }
            return Figure;
        }
      

    }

}
