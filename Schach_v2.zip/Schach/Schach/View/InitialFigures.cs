﻿using System;
using System.Windows.Media;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace Schach
{
    public class InitialModels
    {
        private HelixViewport3D myhelixViewport;
        private List<IModel> models;
        public InitialModels(HelixViewport3D myhelixViewport, List<IModel> models)
        {
            this.myhelixViewport = myhelixViewport;
            this.models = models;
            getAllBlackModels(Colors.Gray);
            getAllWhiteModels(Colors.White);

        }
        private void getAllBlackModels(Color brush)
        {
            Figure figure = new Figure();
            Point3D position = new Point3D();
            Model model = new Model();

            for (int i = 0; i < 800; i += 100)
            {
                position.X = 600;
                position.Y = i;

                figure = new Figure();
                figure.Element = model.Load("fFarmerBlack", @"Figuren\BAUER_STL.stl", brush, position);
                figure.Color = ChessColors.BLACK;
                myhelixViewport.Children.Add(figure.Element);
                models.Add(figure);
                
            }


            position.X = 700;
            figure = new Figure();
            position.Y = 100;
            figure.Element = model.Load("fRunner", @"Figuren\LAEUFER_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 600;
            figure.Element = model.Load("fRunner", @"Figuren\LAEUFER_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 200;
            figure.Element = model.Load("fHorse", @"Figuren\Ross_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 500;
            figure.Element = model.Load("fHorse", @"Figuren\Ross_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 300;
            figure.Element = model.Load("fQueen", @"Figuren\KING_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 400;
            figure.Element = model.Load("fKing", @"Figuren\QUEEN_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 0;
            figure.Element = model.Load("fTower", @"Figuren\Turm_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);

            figure = new Figure();
            position.Y = 700;
            figure.Element = model.Load("fTower", @"Figuren\Turm_STL.stl", brush, position);
            figure.Color = ChessColors.BLACK;
            myhelixViewport.Children.Add(figure.Element);
            models.Add(figure);
        }
        private void getAllWhiteModels(Color brush)
        {
            Figure figure = new Figure();
            Point3D position = new Point3D();
            Model model = new Model();

            for (int i = 0; i< 800; i += 100)
            {
                position.X = 100;
                position.Y = i;

                figure = new Figure();
                figure.Element = model.Load("fFarmerWhite", @"Figuren\BAUER_STL.stl", brush, position);
                figure.Color = ChessColors.WHITE;
                myhelixViewport.Children.Add(figure.Element);

                models.Add(figure);
            }

            position.X = 0;
            figure = new Figure();
            position.Y = 100;
            figure.Element = model.Load("fRunner", @"Figuren\LAEUFER_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 600;
            figure.Element = model.Load("fRunner", @"Figuren\LAEUFER_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 200;
            figure.Element = model.Load("fHorse", @"Figuren\Ross_STL.stl", brush, position);
               
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 500;
            figure.Element = model.Load("fHorse", @"Figuren\Ross_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 300;
            figure.Element = model.Load("fQueen", @"Figuren\KING_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 400;
            figure.Element = model.Load("fKing", @"Figuren\QUEEN_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 0;
            figure.Element = model.Load("fTower", @"Figuren\Turm_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

            figure = new Figure();
            position.Y = 700;
            figure.Element = model.Load("fTower", @"Figuren\Turm_STL.stl", brush, position);
            myhelixViewport.Children.Add(figure.Element);
            figure.Color = ChessColors.WHITE;
            models.Add(figure);

        }
    }
}
