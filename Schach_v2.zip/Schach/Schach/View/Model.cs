﻿using System;
using System.Windows.Input;
using System.Windows.Media;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;

namespace Schach
{
    public class Model
    {

        public ModelUIElement3D Load(string name ,string path, Color brush, Point3D tr)
        {
            TranslateTransform3D translate = new TranslateTransform3D();
            ScaleTransform3D scale = new ScaleTransform3D();
            ModelImporter importer = new ModelImporter();
            ModelUIElement3D figure = new ModelUIElement3D();
            Model3D model;
            Transform3DGroup tGroup = new Transform3DGroup();

       

            importer.DefaultMaterial = new DiffuseMaterial(new SolidColorBrush(brush));
            model = importer.Load(path);
            scale = Scale(2, 2, 2, -50, -50, -100);
           
            if(name == "fHorse" && brush == Colors.Gray)
            {
                RotateTransform3D tt = new RotateTransform3D();
                tt.CenterX = 0;
                tt.Rotation = new AxisAngleRotation3D(new Vector3D(0, 0, 1), 180);
                tGroup.Children.Add(tt);
            }
            tGroup.Children.Add(scale);
            translate = Translate(tr.X, tr.Y, tr.Z);
            model.Transform = tGroup;
            figure.Model = model;
            figure.SetName(name);  
            figure.Transform = translate;
            figure.MouseDown += Moving.Move;
            return figure;

        }
        private ScaleTransform3D Scale(int scaleX, int scaleY, int scaleZ, int centerX, int centerY, int centerZ)
        {
            ScaleTransform3D scale = new ScaleTransform3D();
            scale.ScaleX = scaleX;
            scale.ScaleY = scaleY;
            scale.ScaleZ = scaleZ;

            scale.CenterX = centerX;
            scale.CenterY = centerY;
            scale.CenterZ = centerZ;

            return scale;

        }
        private TranslateTransform3D Translate(double offsetX , double offsetY, double offsetZ)
        {
            TranslateTransform3D translate = new TranslateTransform3D();

            translate.OffsetX = offsetX;
            translate.OffsetY = offsetY;
            translate.OffsetZ = offsetZ;
            

            return translate;
        }

    }
}
