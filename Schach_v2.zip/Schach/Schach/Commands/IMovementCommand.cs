﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schach
{
    public interface IMovementCommand
    {
        bool execute(Schach.IModel sourceModel, Schach.IModel targetModel);
    }
    public class MovementStay : IMovementCommand
    {
        public bool execute(IModel sourceModel, IModel targetModel)
        {
            Occupier tile = new Occupier();
            tile.unset(targetModel.getElement());
            AnimationHandler handler = new AnimationHandler();
            sourceModel.Occupied = true;
            handler.AnimateFigure(targetModel.getElement(), sourceModel.getElement());
            IStateThrowStay state = new StateStay();
            state.throwFigure(null);
            return true;
        }
    }
    public class MovementThrow : IMovementCommand
    {
        public bool execute(IModel sourceModel, IModel targetModel)
        {
            Occupier tile = new Occupier();
            tile.unset(targetModel.getElement());
            AnimationHandler handler = new AnimationHandler();
            sourceModel.Occupied = true;
            handler.AnimateFigure(targetModel.getElement(), sourceModel.getElement());
            IStateThrowStay state = new StateThrow();
            state.throwFigure(sourceModel);
            return true;
        }
    }
    public class MovementNull : IMovementCommand
    {
        public bool execute(IModel sourceModel, IModel targetModel)
        {
            sourceModel = null;
            targetModel = null;
            return false;
        }
    }
}
