﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace Schach
{
    public interface IPlayer
    {
        IPlayer nextPlayer();
        ChessColors Color { get; set; }
    }
    public class Player1 : IPlayer
    {
        public ChessColors Color { get { return ChessColors.BLACK; } set { } }

        PerspectiveCamera Camera = new PerspectiveCamera();
        public Player1(PerspectiveCamera camera)
        {
        

            camera.Position = new Point3D(1600, 400, 1300);
            camera.LookDirection = new Vector3D(-2, 0, -2);
            camera.UpDirection = new Vector3D(0, 0, 1);
            camera.FieldOfView = 60;
            Camera = camera;

            

             Synchronize.syncCamera(Camera);
    
        }
        public IPlayer nextPlayer()
        {
            PerspectiveCamera secondCamera = new PerspectiveCamera();

            secondCamera.Position = new Point3D(-800, 400, 1300);
            secondCamera.LookDirection = new Vector3D(2, 0, -2);
            secondCamera.UpDirection = new Vector3D(0, 0, 1);
            secondCamera.FieldOfView = 60;

            AnimationHandler a = new AnimationHandler();
            a.AnimateCamera(Camera, secondCamera);
            return new Player2(Camera);
        }
    }
    public class Player2 : IPlayer
    {
        PerspectiveCamera Camera = new PerspectiveCamera();
        public ChessColors Color { get { return ChessColors.WHITE; } set { } }
        public Player2(PerspectiveCamera camera)
        {

            camera.Position = new Point3D(-800, 400, 1300);
            camera.LookDirection = new Vector3D(2, 0, -2);
            camera.UpDirection = new Vector3D(0, 0, 1);
            camera.FieldOfView = 60;
            Camera = camera;
            Synchronize.syncCamera(Camera);

        }
        public IPlayer nextPlayer()
        {
            return new Player1(Camera);
        }
    }
}
