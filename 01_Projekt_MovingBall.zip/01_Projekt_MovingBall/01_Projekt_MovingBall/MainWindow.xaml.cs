﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace _01_Projekt_MovingBall
{

    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        List<IShape> undo = new List<IShape>();
        public Color myColor;
        List<AShape> shapes = new List<AShape>();
        public DispatcherTimer mainEllipses = new DispatcherTimer();
        public AnalyseColor analyseColor = new AnalyseColor();
        public MainWindow()
        {
            InitializeComponent();
            RenderOptions.SetBitmapScalingMode(Fundament, VisualBitmapScalingMode);
            myColor = Color.FromRgb(255, 0, 0);
            myCanvas.Fundament = Fundament;
        }
        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            byte[] rgb = new byte[3];
            rgb = analyseColor.colorAnalyse(checkboxrot.IsChecked, checkboxgrün.IsChecked, checkboxblau.IsChecked);
            myColor = Color.FromRgb(rgb[0], rgb[1], rgb[2]); 
        }
        private void circle_Click(object sender, RoutedEventArgs e)
        {
            IShape ellipse = new EllipseShape( myColor);
            ellipse.init(20,20);
            ellipse.Start();
            undo.Add(ellipse);
        }
        private void Rectangle_Click_1(object sender, RoutedEventArgs e)
        {
            IShape rectangle = new RectangleShape( myColor);
            rectangle.init(20, 20);
            rectangle.Start();
            undo.Add(rectangle);
        }

        private void Triangle_Click(object sender, RoutedEventArgs e)
        {
            IShape triangle = new TriangleShape( myColor);
            triangle.init(20, 20);
            triangle.Start();
            undo.Add(triangle);
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (undo.Count != 0)
            {
                int index = undo.Count - 1;
                IShape d = undo[index];
                d.Stop();
                Fundament.Children.Remove(d.getShape());
                undo.RemoveAt(undo.Count - 1);
            }
        }

        private void speed_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
