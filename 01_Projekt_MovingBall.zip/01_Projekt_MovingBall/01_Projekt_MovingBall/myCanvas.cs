﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace _01_Projekt_MovingBall
{
    static public class myCanvas
    {
        static Random randy = new Random();
        private static Canvas fundament;
        public static Canvas Fundament { get { return fundament; } set { fundament = value; } }

        public static void setPosition(Shape RenderShape)
        {
            Canvas.SetLeft(RenderShape, randy.Next(0, Convert.ToInt32(Fundament.ActualWidth)));
            Canvas.SetTop(RenderShape, randy.Next(0, Convert.ToInt32(Fundament.ActualHeight)));
        }
    }
}
