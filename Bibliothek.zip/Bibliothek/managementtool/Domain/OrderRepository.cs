﻿using managementtool.Context;
using managementtool.Model;
using managementtool.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.Domain
{
    class OrderRepository : IRepository<Order>
    {
        private SBOContext sbocontext;

        public OrderRepository()
        {
            sbocontext = new SBOContext();
        }
        public OrderRepository(SBOContext sbocontext)
        {
            this.sbocontext = sbocontext;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    sbocontext.Dispose();
                }
            }
            this.disposed = true;
        }
        private bool disposed = false;
        public void create(Order entity)
        {
            sbocontext.Orders.Add(entity);
        }

        public void delete(int id)
        {
            Order order = sbocontext.Orders.Find(id);
            sbocontext.Orders.Remove(order);
        }
        public IEnumerable<Order> getAll()
        {
            return sbocontext.Orders.ToList();
        }

        public Order getOne(int id)
        {
            return sbocontext.Orders.Find(id);
        }

        public void save()
        {
            sbocontext.SaveChanges();
        }

        public void update(Order entity)
        {
            sbocontext.Entry(entity).State = System.Data.Entity.EntityState.Modified;
        }
        public List<ViewOrder> getOrders()
        {
            Student student;
            Book book;
            List<ViewOrder> list = new List<ViewOrder>();
            ViewOrder orderView = new ViewOrder();

            StudentRepository studentRepository = new StudentRepository();
            BookRepository bookRepository = new BookRepository();

            List<Order> orders = getAll().ToList();

            foreach(var item in orders)
            {
                student = studentRepository.getOne(item.Student_Id);
                book = bookRepository.getOne(item.Book_Id);

                if(book == null) { orderView.Book = "NO_CONTENT"; } else
                orderView.Book = book.Title + " " + book.Author;

                if(student == null) { orderView.Student = "NO_CONTENT"; } else
                orderView.Student = student.Firstname + " " + student.Lastname;

                orderView.Id = item.Id;
                orderView.Date = item.Date;
                list.Add(orderView);
                orderView = new ViewOrder();
            }
            return list;
        }
    }
}
