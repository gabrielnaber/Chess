﻿using managementtool.Context;
using managementtool.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace managementtool.Domain
{
    class StudentRepository : IRepository<Student>
    {
        private SBOContext sbocontext;

        public StudentRepository(SBOContext sbocontext)
        {
            this.sbocontext = sbocontext;
        }

        public StudentRepository()
        {
            this.sbocontext = new SBOContext();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    sbocontext.Dispose();
                }
            }
            this.disposed = true;
        }

        public IEnumerable<Student> getAll()
        {
            return sbocontext.Students.ToList();
        }

        public Student getOne(int id)
        {
            return sbocontext.Students.Find(id);
        }

        public void save()
        {
            sbocontext.SaveChanges();
        }

        public void update(Student entity)
        {
            sbocontext.Entry(entity).State = System.Data.Entity.EntityState.Modified;
        }
        public void create(Student entity)
        {
            sbocontext.Students.Add(entity);
        }

        public void delete(int id)
        {
            Student student = sbocontext.Students.Find(id);
            sbocontext.Students.Remove(student);
        }
        public List<Student> selectStudentsByName(string name)
        {

            List<Student> students = getAll().ToList();

            List<Student> stu =
                students.Where(item => item.Lastname.Contains(name)).ToList();

            return stu;
        }
    }
}
