﻿using managementtool.Context;
using managementtool.Domain;
using managementtool.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.Domain
{
    class BookRepository : IRepository<Book>
    {
        private SBOContext sbocontext;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        private bool disposed = false;

        public BookRepository(SBOContext sbocontext)
        {
            this.sbocontext = sbocontext;
        }
        public BookRepository()
        {
            this.sbocontext = new SBOContext();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    sbocontext.Dispose();
                }
            }
            this.disposed = true;
        }
        public void create(Book entity)
        {
            sbocontext.Books.Add(entity);
        }

        public void delete(int id)
        {
            Book book = sbocontext.Books.Find(id);
            sbocontext.Books.Remove(book);
        }

        public IEnumerable<Book> getAll()
        {
            return sbocontext.Books.ToList();
        }
        public void addBooks(List<Book> books)
        {
            foreach(Book book in books)
            {
                sbocontext.Books.Add(book);
            }
        }

        public Book getOne(int id)
        {
            return sbocontext.Books.Find(id);
        }

        public void save()
        {
            sbocontext.SaveChanges();
        }

        public void update(Book entity)
        {
            sbocontext.Entry(entity).State = System.Data.Entity.EntityState.Modified;
        }
        public List<Book> selectBooksByTitle(string title)
        {
            List<Book> books = getAll().ToList();

            List<Book> boo = books.Where(item => item.Title.Contains(title)).ToList();

            return boo;
        }
    }
}
