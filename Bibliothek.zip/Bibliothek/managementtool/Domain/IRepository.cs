﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.Domain
{
    interface IRepository<T> : IDisposable
    {
        IEnumerable<T> getAll();
        void create(T entity);
        void delete(int id);
        void update(T entity);
        void save();
        T getOne(int id);

    }
}
