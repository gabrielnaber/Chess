﻿using managementtool.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace managementtool.XML
{
    class XMLImport
    {
        public List<Book> readFile(string path)
        {
            List<Book> books = new List<Book>();

            StringBuilder result = new StringBuilder();

            try
            {
                foreach (XElement level1Element in XElement.Load(@path).Elements("book"))
                {

                    Book book = new Book();
                    int length = Convert.ToInt32(level1Element.Attribute("id").Value.Length);
                    book.Id = Convert.ToInt32(level1Element.Attribute("id").Value.Substring(2, length - 2));
                    book.Author = level1Element.Element("author").Value;
                    book.Title = level1Element.Element("title").Value;
                    float val = Convert.ToSingle(level1Element.Element("price").Value.Replace('.', ','));
                    book.Price = (int)val;
                    books.Add(book);

                }
            }
            catch(Exception e)
            {
                //lol
            }
            return books;
        }
    }
}
