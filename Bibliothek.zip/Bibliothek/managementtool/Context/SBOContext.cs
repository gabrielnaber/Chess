﻿using managementtool.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.Context
{
    class SBOContext : DbContext
    {
        public DbSet<Order> Orders { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Student> Students { get; set; }

        public SBOContext() : base("SBOContext")
        {
            Database.SetInitializer<SBOContext>
                (new DropCreateDatabaseIfModelChanges<SBOContext>());

            AppDomain.CurrentDomain.SetData("DataDirectory", System.IO.Directory.GetCurrentDirectory());
        }
    }
}
