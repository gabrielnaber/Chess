﻿using Caliburn.Micro;
using managementtool.Domain;
using managementtool.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.ViewModels
{
    class BookViewModel : Screen
    {

        public BookViewModel()
        {
            repository = new BookRepository();
        }
        private BookRepository repository;
        private int _price;
        public int Price
        {
            get
            {
                return _price;
            }

            set
            {
                _price = value;
                NotifyOfPropertyChange(() => Price);
            }
        }
        public string Title
        {
            get
            {
                return _title;
            }

            set
            {
                _title = value;
                NotifyOfPropertyChange(()=>Title);
            }
        }
        public string Author
        {
            get
            {
                return _author;
            }

            set
            {
                _author = value;
                NotifyOfPropertyChange(() => Author);
            }
        }
        private string _title;
        private string _author;
        
        

        public void CreateBook()
        {
            Book book = new Book();
            book.Author = Author;
            book.Price = Price;
            book.Title = Title;

            repository.create(book);
            repository.save();
            repository.Dispose();
            this.TryClose();

        }   
    }
}
