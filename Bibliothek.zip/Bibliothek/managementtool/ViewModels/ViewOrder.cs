﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.ViewModels
{
    class ViewOrder
    {
        private int _id;
        private string _student;
        private string _book;

        private string _date;

        public string Student
        {
            get
            {
                return _student;
            }

            set
            {
                _student = value;
            }
        }

        public string Book
        {
            get
            {
                return _book;
            }

            set
            {
                _book = value;
            }
        }

        public string Date
        {
            get
            {
                return _date;
            }

            set
            {
                _date = value;
            }
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }
    }
}
