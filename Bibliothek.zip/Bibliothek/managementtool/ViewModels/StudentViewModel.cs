﻿using Caliburn.Micro;
using managementtool.Context;
using managementtool.Domain;
using managementtool.Model;
using managementtool.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.ViewModels
{
    class StudentViewModel : Screen
    {
        private SBOContext context;
        private StudentRepository repository;

        private Student student;
        public StudentViewModel(Student student)
        {
            this.student = student;
        }
        public StudentViewModel() { }
        public string Firstname
        {
            get
            {
                return _firstname;
            }

            set
            {
                _firstname = value;
                NotifyOfPropertyChange(() => Firstname);
            }
        }
        public string Lastname
        {
            get
            {
                return _lastname;
            }

            set
            {
                _lastname = value;
                NotifyOfPropertyChange(() => Lastname);
            }
        }
        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
                NotifyOfPropertyChange(() => Age);
            }
        }

        private string _firstname;
        private string _lastname;
        private int _age;


        public void CreateStudent()
        {


            repository = new StudentRepository(new SBOContext());
            if (student == null)
            {
                student = new Student();
                student.Firstname = Firstname;
                student.Lastname = Lastname;
                student.Age = Age;
                repository.create(student);
            }
            else
            {
                student.Firstname = Firstname;
                student.Lastname = Lastname;
                student.Age = Age;
                repository.update(student);
            }
            repository.save();
            repository.Dispose();
            this.TryClose();
        }
    }
}