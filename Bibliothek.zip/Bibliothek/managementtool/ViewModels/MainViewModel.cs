﻿using Caliburn.Micro;
using managementtool.Domain;
using managementtool.Model;
using managementtool.Views;
using managementtool.XML;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.ViewModels
{
    class MainViewModel : Conductor<object>
    {
        public WindowManager manager = new WindowManager();
        private Context.SBOContext sbocontext;

        StudentRepository studentRepository;
        BookRepository bookRepository;
        OrderRepository orderRepository;

        public MainViewModel()
        {
            Reload();
        }
        public void AddStudent()
        {
            manager.ShowDialog(new StudentViewModel());
            Reload();

        }
        public void AddBook()
        {
            manager.ShowDialog(new BookViewModel());
            Reload();
        }
        public void AddOrder()
        {
            manager.ShowDialog(new OrderViewModel());
            Reload();
        }
        public void RemoveBook()
        {
            if (SelectedBook != null)
            {
                bookRepository.delete(SelectedBook.Id);
                bookRepository.save();
                bookRepository.Dispose();
                Reload();
            }
        }
        public void RemoveStudent()
        {
            if (SelectedStudent != null)
            {
                studentRepository.delete(SelectedStudent.Id);
                studentRepository.save();
                bookRepository.Dispose();
                Reload();
            }
        }
        public void RemoveOrder()
        {
            if (SelectedOrder != null)
            {
                orderRepository.delete(SelectedOrder.Id);
                orderRepository.save();
                bookRepository.Dispose();
                Reload();
            }
        }

        public void FileImport()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();
            string path = openFileDialog.FileName;

            XMLImport importer = new XMLImport();

            List<Book> books = importer.readFile(path);

            BookRepository repository = new BookRepository();
            repository.addBooks(books);
            repository.save();
            repository.Dispose();
            Reload();
        }
        private void Reload()
        {
            sbocontext = new Context.SBOContext();

             studentRepository = new StudentRepository(sbocontext);
            if (SearchStudent != null)
            {
                _students = studentRepository.selectStudentsByName(SearchStudent);
            }
            else
            {
                _students = studentRepository.getAll().ToList();
            }
            Students = _students;

             bookRepository = new BookRepository(sbocontext);

            if (SearchBook != null)
            {
                _books = bookRepository.selectBooksByTitle(SearchBook);
            }
            else
            {
                _books = bookRepository.getAll().ToList();
            }
            Books = _books;

             orderRepository = new OrderRepository(sbocontext);
            _orders = orderRepository.getOrders().ToList();
            Orders = _orders;
            
        }
        public void DeleteDatabase()
        {
            sbocontext.Database.Delete();
            sbocontext.SaveChanges();
            Reload();
        }
        public void SaveChanges()
        {
            sbocontext.SaveChanges();
        }
        public void UpdateStudent()
        {
            if (SelectedStudent != null)
            {
                Student student = new Student();
           

                student.Firstname = SelectedStudent.Firstname;
                student.Lastname = SelectedStudent.Lastname;
                student.Age = SelectedStudent.Age;

                StudentViewModel studentmodel = new StudentViewModel(student);
                studentmodel.Firstname = SelectedStudent.Firstname;
                studentmodel.Lastname = SelectedStudent.Lastname;
                studentmodel.Age = SelectedStudent.Age;

                manager.ShowDialog(studentmodel);
                Reload();
            }
           
        }
        public void UpdateBook()
        {
            if (SelectedBook != null)
            {
                BookViewModel bookmodel = new BookViewModel();
                bookmodel.Title = SelectedBook.Title;
                bookmodel.Author = SelectedBook.Author;
                bookmodel.Price = (int)SelectedBook.Price;
                manager.ShowDialog(bookmodel);
                Reload();
            }
        }
        private List<Book> _books = new List<Book>();
        private List<Student> _students = new List<Student>();
        private List<ViewOrder> _orders = new List<ViewOrder>();
        public List<Student> Students
        {
            get
            {
                return _students;
            }

            set
            {
                _students = value;
                NotifyOfPropertyChange(() => Students);
            }
        }

        public List<Book> Books
        {
            get
            {
                return _books;
            }

            set
            {
                _books = value;
                NotifyOfPropertyChange(() => Books);
            }
        }

        public List<ViewOrder> Orders
        {
            get
            {
                return _orders;
            }

            set
            {
                _orders = value;
                NotifyOfPropertyChange(()=>Orders);
            }
        }

        public Student SelectedStudent
        {
            get
            {
                return _selectedStudent;
            }

            set
            {
                _selectedStudent = value;
                NotifyOfPropertyChange(() => SelectedStudent);
            }
        }

        public Book SelectedBook
        {
            get
            {
                return _selectedBook;
            }

            set
            {
                _selectedBook = value;
                NotifyOfPropertyChange(() => SelectedBook);
            }
        }

        public ViewOrder SelectedOrder
        {
            get
            {
                return _selectedOrder;
            }

            set
            {
                _selectedOrder = value;
                NotifyOfPropertyChange(() => SelectedOrder);
            }
        }

        public string SearchStudent
        {
            get
            {
                return _searchStudent;
            }

            set
            {
                _searchStudent = value;
                NotifyOfPropertyChange(() => SearchStudent);
                Reload();
            }
        }

        public string SearchBook
        {
            get
            {
                return _searchBook;
            }

            set
            {
                _searchBook = value;
                NotifyOfPropertyChange();
                Reload();
            }
        }

        private Student _selectedStudent;
        private Book _selectedBook;
        private ViewOrder _selectedOrder;

        private string _searchStudent;
        private string _searchBook;

    }
}
