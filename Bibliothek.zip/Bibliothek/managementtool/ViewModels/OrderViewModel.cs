﻿using Caliburn.Micro;
using managementtool.Context;
using managementtool.Domain;
using managementtool.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managementtool.ViewModels
{
    class OrderViewModel : Screen
    {
        StudentRepository studentRepository;
        BookRepository bookRepository;
        OrderRepository orderRepository;
        public OrderViewModel()
        {
            SBOContext context = new SBOContext();

            studentRepository = new StudentRepository(context);
            bookRepository = new BookRepository(context);
            orderRepository = new OrderRepository(context);

            _selectStudents = studentRepository.getAll().ToList();
            SelectStudents = _selectStudents;

            _selectBooks = bookRepository.getAll().ToList();
            SelectBooks = _selectBooks;



        }
        private Student _selectedStudent;
        private List<Student> _selectStudents;
        public List<Student> SelectStudents
        {
            get
            {
                return _selectStudents;
            }

            set
            {
                _selectStudents = value;
                NotifyOfPropertyChange();
            }
        }
        public Student SelectedStudent
        {
            get
            {
                return _selectedStudent;
            }

            set
            {
                _selectedStudent = value;
                NotifyOfPropertyChange(() => SelectedStudent);
            }
        }

        private List<Book> _selectBooks;
        public List<Book> SelectBooks
        {
            get
            {
                return _selectBooks;
            }

            set
            {
                _selectBooks = value;
                NotifyOfPropertyChange();
            }
        }
        public Book SelectedBook
        {
            get
            {
                return _selectedBook;
            }

            set
            {
                _selectedBook = value;
                NotifyOfPropertyChange(() => SelectedBook);
            }
        }

        public DateTime Date
        {
            get
            {
                return _date;
            }

            set
            {
                _date = value;
                NotifyOfPropertyChange(() => Date);
            }
        }

        private Book _selectedBook;

        private DateTime _date = DateTime.Now;

        public void DoOrder()
        {
            Order order = new Order();

            order.Book_Id = SelectedBook.Id;
            order.Student_Id = SelectedStudent.Id;
            order.Date = Date.ToString("MM:dd:yyyy");

            

            orderRepository.create(order);
            orderRepository.save();
            orderRepository.Dispose();
            this.TryClose();
        }
    }
}
