﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SemaphorenExample
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Product> products = new List<Product>()
            {
                new Product(1),
                new Product(2),
                new Product(3),
                new Product(4),
                new Product(5)
            };

            int counter = 0;

            MaschineA ma = new MaschineA();
            MaschineB mb = new MaschineB();
            ConveryorBelt c = new ConveryorBelt();


            Thread maschineA = new Thread(ma.run);
            Thread maschineB = new Thread(mb.run);

            Thread converyorbelt = new Thread(c.run);

            maschineA.Start();
            maschineB.Start();
            converyorbelt.Start();

            while (products.Count > counter)
            {
                Product b = products[counter];

                ma.product = b;
                mb.product = b;
                c.product = b;
                
            }
            Console.ReadKey();
        }
    }
    class Product
    {
        public int Number { get; set; }

        public Product(int number)
        {
            Number = number;
        }

        int progress = 0;
        public int Progress { get { return progress; } set { if (progress >= 2) {  finished = true; } else { progress = value; } } }

        public bool finished = false;

    }
    interface Runnable
    {
        void run();
    }
     class MaschineA : Runnable
    {
        public Product product { get; set; }

        public static Semaphore maschineA = new Semaphore(0,2);     

        public void run()
        {
            maschineA.WaitOne();
            while (true)
            {
                
                work();
                
                if (product.finished)
                {
                    break;
                }
                ConveryorBelt.conv.Release();
                maschineA.WaitOne();
            }
        }
        public void work()
        {
           
            product.Progress++;
            Console.WriteLine("Progress: " + product.Progress + " Produkt " + product.Number + " A");
        }
    }
     class MaschineB : Runnable
     {
       public Product product { get; set; }

        public static Semaphore maschineB = new Semaphore(0,2);
        public void run()
        {
            maschineB.WaitOne();
            while (true)
            {      
                work();
                if (product.finished)
                {
                    break;
                }
                ConveryorBelt.conv.Release();
                maschineB.WaitOne();
            }
            
        }
        public void work()
        {
            
            product.Progress++;
            Console.WriteLine("Progress: " + product.Progress + " Produkt " + product.Number + " B");
        }
    }
     class ConveryorBelt : Runnable
    {
        public Product product { get; set; }

        public static Semaphore conv = new Semaphore(0,3);
        public void run()
        {
            while (true)
            {
                move();
                MaschineA.maschineA.Release();
                conv.WaitOne();
                move();
                MaschineB.maschineB.Release();
                conv.Release();

                conv = new Semaphore(0, 3);
                MaschineA.maschineA = new Semaphore(0, 2);
                MaschineB.maschineB = new Semaphore(0, 2);
                
            }
            
        }
        public void move()
        {
            Console.WriteLine("Move");
        }
    }
}
