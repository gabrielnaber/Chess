﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPU.Singleton
{
    class BlockQueue : BlockingCollection<MyThread>
    {
        public static BlockQueue queue;
        private static object lockobj = new object();
        public static BlockQueue get()
        {
            lock (lockobj)
            {
                if (queue == null)
                {
                    queue = new BlockQueue();
                }
                return queue;
            }
        }

    }
}