﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPU.Singleton
{
    class RunningQueue : BlockingCollection<MyThread>
    {
        public static RunningQueue queue;

        private static object lockobj = new object();
        public static RunningQueue get()
        {
            lock (lockobj)
            {
                if (queue == null)
                {
                    queue = new RunningQueue();
                }
                return queue;
            }
        }
    }
}
