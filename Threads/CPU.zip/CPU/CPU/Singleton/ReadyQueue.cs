﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPU.Singleton
{
    class ReadyQueue : BlockingCollection<MyThread>
    {
        public static ReadyQueue queue;

        private static object lockobj = new object();
        public static ReadyQueue get()
        {
            lock (lockobj)
            {
                if (queue == null)
                {
                    queue = new ReadyQueue();
                }
                return queue;
            }
        }
    }
}
