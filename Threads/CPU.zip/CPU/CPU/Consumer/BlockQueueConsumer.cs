﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPU.Singleton;
using CPU;

namespace CPU.Consumer
{
    class BlockQueueConsumer : IQueueConsumer
    {
        BlockQueue queue = BlockQueue.get();

        public void run()
        {
            MyThread next;
            while (true)
            {
                try
                {
                    next = queue.Take();
                    next.nextState();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
