﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPU.Singleton;
using CPU.Consumer;
using CPU.States;

namespace CPU.Consumer
{
    class RunningQueueConsumer
    {
        RunningQueue queue = RunningQueue.get();

        public void run()
        {
            MyThread next;

            while (true)
            {
                try
                { 
                    next = queue.Take();
                    next.nextState();
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
