﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPU.States
{
    class RunningState : IState
    {
        static Random randy = new Random();
        public IState changeState(MyThread thread)
        {
            Console.WriteLine("Running: "+ thread.GetHashCode().ToString());
            int i = randy.Next(0, 3);

            if(i == 0)
            {
                return new BlockedState();
            }
            else if(i == 1)
            {
                return new FinishedState();
            }
            else if(i == 2)
            {
                return new ReadyState();
            }
            return new FinishedState();
            
        }
    }
}
