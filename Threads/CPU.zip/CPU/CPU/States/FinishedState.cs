﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPU.States
{
    class FinishedState : IState
    {
        public IState changeState(MyThread thread)
        {
            Console.WriteLine("Finished: " + thread.GetHashCode().ToString());
            return null;
        }
    }
}
