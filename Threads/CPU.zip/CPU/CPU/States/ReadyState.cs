﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPU.States
{
    class ReadyState : IState
    {
        public IState changeState(MyThread thread)
        {
            Console.WriteLine("Ready: " + thread.GetHashCode().ToString());
            return new RunningState();
        }
    }
}
