﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPU.Singleton;

namespace CPU.States
{
    class BlockedState : IState
    {
        public IState changeState(MyThread thread)
        {
            Console.WriteLine("Blocked: " + thread.GetHashCode().ToString());
            return new ReadyState();

        }
    }
}
