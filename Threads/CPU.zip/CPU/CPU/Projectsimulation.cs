﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPU.Singleton;
using CPU.Consumer;

namespace CPU
{
    class Projectsimulation
    {
        public void startSimulation()
        {
            BlockQueue blockQueue = BlockQueue.get();
            ReadyQueue readyQueue = ReadyQueue.get();
            RunningQueue runningQueue = RunningQueue.get();

            ReadyQueueConsumer readyConsumer = new ReadyQueueConsumer();
            RunningQueueConsumer runningConsumer = new RunningQueueConsumer();
            BlockQueueConsumer blockConsumer = new BlockQueueConsumer();


            for(int i = 0; i < 10; i++)
            {
                MyThread t = new MyThread();
                Task.Run(() => t);
            }     
            Task.Run(() => readyConsumer.run());
            Task.Run(() => runningConsumer.run());
            Task.Run(() => blockConsumer.run());

            Console.ReadKey();
        }
    }
}
