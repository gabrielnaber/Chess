﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPU.Consumer;
using CPU.Singleton;
using CPU.States;

namespace CPU
{

    class MyThread : IDisposable
    {
        public IState state { get; set; }
        private bool disposed = false;

        public MyThread()
        {
            state = new ReadyState();
            ReadyQueue.get().TryAdd(this);
        }

        public void nextState()
        {
            state = state.changeState(this);

            if (state.GetType() == typeof(ReadyState))
            {
                ReadyQueue.get().TryAdd(this);
            }
            else if (state.GetType() == typeof(BlockedState))
            {
                BlockQueue.get().TryAdd(this);
            }
            else if (state.GetType() == typeof(RunningState))
            {
                RunningQueue.get().TryAdd(this);
            }
            else if (state.GetType() == typeof(FinishedState))
            {
                Dispose();
            }

        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            Console.WriteLine("Disposed: " + this.GetHashCode().ToString());
            if (!this.disposed)
            {
                if (disposed)
                {
                    this.Dispose();
                }
            }
            disposed = true;
        }
        ~MyThread()
        {
           
            Dispose(false);
        }


    }
}
