﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Calculate
{
    class Program
    {
        static void Main(string[] args)
        {
            Producer p = new Producer();
            Consumer c = new Consumer();
            MyMath t = new MyMath();

            Task task = Task.Run(() => p.Produce());

            Console.ReadKey();
        }
    }
    class Producer
    {

        static Random yx = new Random();
        public static BlockingCollection<MyMath> queue = new BlockingCollection<MyMath>();
        public void Produce()
        {
            MyMath t;
            while (true)
            {
                t = new MyMath();
                t.X = yx.Next(0, 10);
                t.Y = yx.Next(10, 20);
                queue.Add(t);
                Console.WriteLine(t.X + " + " + t.Y + " = 0");
                Thread.Sleep(100);
            }
        }

        
    }
    class Consumer
    {
        public Consumer()
        {
            Task t = Task.Run(() => StartConsuming());
            
        }
        public static void StartConsuming()
        {
            while (true)
            {
                MyMath item = Producer.queue.Take();
                item.Calculate();
                Thread.Sleep(200);
            }
        }
    }
    class MyMath
    {
        public int X { get; set; }
        public int Y { get; set; }
        public void Calculate()
        {
            
            Console.WriteLine(X + " + " + Y +" = " + (X+Y));
        }
    }
}
