﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SchiffundHafen
{
    class Program
    {
        static void Main(string[] args)
        {
            int ships = 10;

            for(int i = 0; i < ships; i++)
            {
                Thread s = new Thread(new Ship().run);
                s.Name = "Ship" + (i + 1);
                s.Start();
            }

            Thread h = new Thread(new Harbour().run);
            h.Name = "Harbour";
            h.Start();
            Console.ReadKey();
        }
    }
    class Ship
    {
        static public SemaphoreSlim s_unload = new SemaphoreSlim(0);
        static public SemaphoreSlim s_leave = new SemaphoreSlim(0);
        public void run()
        {
            Harbour.enter();
            unload();
            leave();
        }
        public void unload()
        {
            s_unload.Wait();
            Console.WriteLine("unloads, " + Thread.CurrentThread.Name);
            Harbour.s_unload.Release();
        }
        public void leave()
        {
            s_leave.Wait();
            Console.WriteLine("Ship leaves Harbour");
            Thread.Sleep(2000);
            Harbour.s_enter.Release();
        }
    }
    class Harbour
    {
        static public SemaphoreSlim s_unload = new SemaphoreSlim(0);
        static public SemaphoreSlim s_signal = new SemaphoreSlim(0);
        static public Semaphore s_enter = new Semaphore(3, 3);
        public void run()
        {
            while (true)
            {             
                signal();
                unload();
            }
        }
        public void signal()
        {
            s_signal.Wait();
            Console.WriteLine("Signal"+ Thread.CurrentThread.Name);
            Ship.s_unload.Release();
        }
        public static void enter()
        {
            s_enter.WaitOne();
            Console.WriteLine("Enters" + Thread.CurrentThread.Name);
            s_signal.Release();
           
            Harbour.s_enter.WaitOne();

        }
        public void unload()
        {
            s_unload.Wait();
            Console.WriteLine("Unload,"+ Thread.CurrentThread.Name);
            Thread.Sleep(2000);
            Ship.s_leave.Release();
        }
    }
}
