﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TagDerOffenenTür
{
    class Program
    {
        static void Main(string[] args)
        {
            TdoT.TesteTdoT();
            Console.ReadKey();
        }
    }
    class TdoT
    {
        Semaphore vortrag = new Semaphore(3, 3);
        Semaphore room1 = new Semaphore(0,3);
        Semaphore room23 = new Semaphore(0,6);
        public void GetInfo()
        {
            Discourse();
            VisitRoom1();
            VisitRoom2();
            VisitRoom3();
        }
        public void Discourse()
        {
            vortrag.WaitOne();
            Console.WriteLine("{0} hört den Vortrag", Thread.CurrentThread.Name);
            Thread.Sleep(2000);
            room1.Release();             
        }
        public void VisitRoom1()
        {
            room1.WaitOne();
            Console.WriteLine("{0} im Raum 1", Thread.CurrentThread.Name);
            Thread.Sleep(2000);
            Console.WriteLine("{0} verlässt Raum 1", Thread.CurrentThread.Name);
            room23.Release();
            vortrag.Release();
        }
        public void VisitRoom2()
        {                    
            Console.WriteLine("{0} im Raum 2", Thread.CurrentThread.Name);
            Thread.Sleep(2000);
            Console.WriteLine("{0} verlässt Raum 2", Thread.CurrentThread.Name);
            room23.WaitOne();
        }
        public void VisitRoom3()
        {
            Console.WriteLine("{0} im Raum 3", Thread.CurrentThread.Name);
            Thread.Sleep(2000);
            Console.WriteLine("{0} verlässt Raum 3", Thread.CurrentThread.Name);
            room23.WaitOne();
        }
        public static void TesteTdoT()
        {
            TdoT t = new TdoT();
            for(int i = 0; i < 10; i++)
            {
                Thread thread = new Thread(t.GetInfo);
                thread.Name = String.Concat("Gruppe ", i + 1);
                thread.Start();
            }
        }
    }
}
