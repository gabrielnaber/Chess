﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schach.MoveOptions
{
    public interface IMoveOptions
    {
        bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name);
    }
    public class MoveKing : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            if (name == "fKing")
            {

                double xe = (targetOffsetX - sourceOffsetX);
                double ye = (targetOffsetY - sourceOffsetY);


                if ((xe == 100 || xe == -100) && (ye == 100 || ye == -100))
                {
                    return true;
                }
                if (xe == 0 && (ye == 100 || ye == -100))
                {
                    return true;
                }
                if (ye == 0 && (xe == 100 || xe == -100))
                {
                    return true;
                }

            }
            return false;
        }
    }
    public class MoveQueen : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            if (name == "fQueen")
            {
                if (targetOffsetX == sourceOffsetX || targetOffsetY == sourceOffsetY)
                {
                    return true;

                }
                double xe = (targetOffsetX - sourceOffsetX);
                double ye = (targetOffsetY - sourceOffsetY);


                if (xe == ye || xe == (ye * -1))
                {
                    return true;
                }
            }
            return false;
        }
    }
    public class MoveRunner : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            if (name == "fRunner")
            {
                double xe = (targetOffsetX - sourceOffsetX);
                double ye = (targetOffsetY - sourceOffsetY);

                if (xe == ye || xe == (ye * -1))
                {
                    return true;
                }
            }
            return false;
        }
    }
    public class MoveTower : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {
            if (name == "fTower")
            {
                if (targetOffsetX == sourceOffsetX || targetOffsetY == sourceOffsetY)
                {
                    return true;
                }
            }
            return false;
        }
    }
    public class MoveHorse : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {

            if (name == "fHorse")
            {

                double xe = (targetOffsetX - sourceOffsetX);
                double ye = (targetOffsetY - sourceOffsetY);

                if ((xe == 200 || xe == -200) && (ye == 100 || ye == -100))
                {
                    return true;
                }

                if ((xe == 100 || xe == -100) && (ye == 200 || ye == -200))
                {
                    return true;
                }

            }
            return false;
        }
    }
    public class MoveFarmer : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {

            double xe = (targetOffsetX - sourceOffsetX);
            double ye = (targetOffsetY - sourceOffsetY);
            if (name == "fFarmerBlack")
            {

                if ((xe == 100) && (sourceOffsetY == targetOffsetY))
                {
                    return true;
                }
            }
            if (name == "fFarmerWhite")
            {
                if ((xe == -100) && (sourceOffsetY == targetOffsetY))
                {
                    return true;
                }
            }
            return false;
        }
    }
    public class MoveFarmerThrow : IMoveOptions
    {
        public bool isPossible(double targetOffsetX, double targetOffsetY, double sourceOffsetX, double sourceOffsetY, string name)
        {

            double xe = (targetOffsetX - sourceOffsetX);
            double ye = (targetOffsetY - sourceOffsetY);
            if (name == "fFarmerBlack")
            {

                if ((xe == 100) && (ye == -100 || ye == 100))
                {
                    return true;
                }
            }
            if (name == "fFarmerWhite")
            {
                if ((xe == -100) && (ye == 100 || ye == -100))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
