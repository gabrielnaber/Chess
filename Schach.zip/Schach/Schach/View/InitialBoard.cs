﻿using System;
using System.Windows.Media;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;
using System.Collections.Generic;
using System.Collections.ObjectModel;


namespace Schach
{
    public class InitialBoard
    {
        HelixViewport3D myviewport = new HelixViewport3D();
        List<IModel> models = new List<IModel>();
        public InitialBoard(HelixViewport3D myviewport, List<IModel> models)
        {
            this.myviewport = myviewport;
            this.models = models;
            models = CreateBoard3D();


            foreach (IModel s in models)
            {
                myviewport.Children.Add(s.getElement());
            }

        }

        private List<IModel> CreateBoard3D()
        { 
            CreateBoardofTiles();
            return models;
        }
        
        private void CreateBoardofTiles()
        {
            createTiles(true, 0);
            createTiles(false, 100);
            createTiles(true, 200);
            createTiles(false, 300);
            createTiles(true, 400);
            createTiles(false, 500);
            createTiles(true, 600);
            createTiles(false, 700);
        }
        private int column = 0;
        private void createTiles(bool color, int offsetY)
        {
            SolidColorBrush black = new SolidColorBrush(Colors.Black);
            SolidColorBrush white = new SolidColorBrush(Colors.White);
            TranslateTransform3D transformTile;
            Tile tile = new Tile();
            tile.element = new ModelUIElement3D();
            
            for (int i = 0; i < 800; i += 100)
            {
                tile = new Tile();
                tile.element = new ModelUIElement3D();
                
                transformTile = new TranslateTransform3D();
                if (color)
                {
                    tile.element.Model = CreateGeometryModel3D(black);
                    color = false;
                }
                else if (!color)
                {
                    tile.element.Model = CreateGeometryModel3D(white);
                    color = true;
                }

                
                transformTile.OffsetX = i;
                transformTile.OffsetY = offsetY;
                tile.element.MouseDown += Moving.Move;
                tile.element.Transform = transformTile;
                tile.element.SetName(column.ToString());
                column++;
                models.Add(tile);
            }
        }
        private GeometryModel3D CreateGeometryModel3D(SolidColorBrush col)
        {
            GeometryModel3D modelTile = new GeometryModel3D();

            modelTile.Geometry = TileGeometry();
            modelTile.Material = TileMesh(col);

            return modelTile;
        }
        private MeshGeometry3D TileGeometry()
        {
            MeshGeometry3D temp = new MeshGeometry3D();

            Point3DCollection corners = new Point3DCollection()
            {
                new Point3D(0, 0, 0),
                new Point3D(100, 0, 0),
                new Point3D(0, 100, 0),
                new Point3D(100, 100, 0),
                new Point3D(0, 0, 100),
                new Point3D(100, 0, 100),
                new Point3D(0, 100, 100),
                new Point3D(100, 100, 100)
            };

            Int32Collection triangles = new Int32Collection()
            {
                2,3,1,2,1,0,7,1,3,7,5,1,6,5,7,6,4,5,6,2,0,2,0,4,2,7,3,2,6,7,0,1,5,0,5,4
            };
            temp.Positions = corners;

            temp.TriangleIndices = triangles;
            return temp;
        }
        private DiffuseMaterial TileMesh(SolidColorBrush col)
        {
            DiffuseMaterial temp = new DiffuseMaterial();

            temp.Brush = col;
            return temp;
        }

    }
}
