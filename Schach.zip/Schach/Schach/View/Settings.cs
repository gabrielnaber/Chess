﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;

namespace Schach
{
    public class Settings
    {
        public void configure(HelixViewport3D _myviewport)
        {
            List<IModel> models = new List<IModel>();
            PerspectiveCamera camera = new PerspectiveCamera();
            camera.Position = new Point3D(1600, 400, 1300);
            camera.LookDirection = new Vector3D(-2, 0, -2);
            camera.UpDirection = new Vector3D(0, 0, 1);
            camera.FieldOfView = 60;

            _myviewport.Camera = camera;
            _myviewport.Children.Add(new SunLight());

            InitialBoard board = new InitialBoard(_myviewport, models);
            InitialModels figures = new InitialModels(_myviewport, models);

            Moving.models = models;
            Synchronize.models = models;
            Synchronize.myviewport = _myviewport;
            Occupier o = new Occupier();

            o.synchroneOccupied();
        }
    }
}
