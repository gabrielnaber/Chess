﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;
using System.Windows.Input;

namespace Schach
{
    public enum ChessColors { WHITE, BLACK, DEFAULT };
   public interface IModel
    {
        ModelUIElement3D getElement();
        void setElement(ModelUIElement3D element);

        ChessColors Color { get; set; }
        bool Occupied { get; set; }
        string Name { get; }
    }
   public class Tile : IModel
    {
        public ModelUIElement3D element { get; set; }
        public bool Occupied { get; set; }
        public string Name { get { return "Tile"; } }

        public ModelUIElement3D getElement()
        {
            return element;
        }
        public void setElement(ModelUIElement3D element)
        {
            this.element = element;
        }
        public void setOccupied()
        {
            Occupied = true;
        }
        public void unsetOccupied()
        {
            Occupied = false;
        }
        public ChessColors Color { get { return ChessColors.DEFAULT; } set { } }
    }
   public class Figure : IModel
    {
        public ModelUIElement3D element { get; set; }
        public string Name { get { return "Figure"; } }
        
        public ChessColors Color { get; set; }
        public bool Occupied { get { return true; }  set { } }
        public ModelUIElement3D getElement()
        {
            return element;
        }
        public void setElement(ModelUIElement3D element)
        {
            this.element = element;
        }

    }
}
