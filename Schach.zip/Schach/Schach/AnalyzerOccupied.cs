﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schach
{
   public class AnalyzerOccupied
    {
        public List<IModel> modelsOnTheWay = new List<IModel>();

        public void analyze(List<IModel> models)
        {
            
        }
    }
}
