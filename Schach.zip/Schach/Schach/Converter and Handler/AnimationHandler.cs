﻿using System;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;

namespace Schach
{
     public  class AnimationHandler
    {


        public void Animate(ModelUIElement3D target, ModelUIElement3D source)
        {
            Matrix3D t = target.Transform.Value;
            Matrix3D s = source.Transform.Value;

            int tx = System.Convert.ToInt32(t.OffsetX);
            int ty = System.Convert.ToInt32(t.OffsetY);


            int sx = System.Convert.ToInt32(s.OffsetX);
            int sy = System.Convert.ToInt32(s.OffsetY);

            DoubleAnimation xAnimation =
            new DoubleAnimation(tx, sx, TimeSpan.FromMilliseconds(500));
            DoubleAnimation yAnimation =
            new DoubleAnimation(ty, sy, TimeSpan.FromMilliseconds(500));
            xAnimation.Completed += new EventHandler(animation_completed);
            target.Transform.BeginAnimation(TranslateTransform3D.OffsetXProperty, xAnimation);
            target.Transform.BeginAnimation(TranslateTransform3D.OffsetYProperty, yAnimation);

           

        }
        public void animation_completed(object sender, EventArgs e)
        {
            Moving.player = Moving.player.nextPlayer();
        }
    }
}
