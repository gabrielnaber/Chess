﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace Schach
{
     public class Occupier
     {
        static List<IModel> models = Synchronize.models;
        public void unset(ModelUIElement3D target)
        {
            Matrix3D tt = target.Transform.Value;
            Matrix3D ss = new Matrix3D();
            foreach (IModel t in models)
            {
                ss = t.getElement().Transform.Value;
                if (tt.OffsetX == ss.OffsetX && tt.OffsetY == ss.OffsetY)
                {
                    t.Occupied = false;
                }
            }
        }
        public void set(ModelUIElement3D target)
        {
            Matrix3D tt = target.Transform.Value;
            Matrix3D ss = new Matrix3D();
            foreach (IModel t in models)
            {
                ss = t.getElement().Transform.Value;
                if (tt.OffsetX == ss.OffsetX && tt.OffsetY == ss.OffsetY)
                {
                    t.Occupied = true;
                }
            }
        }
        public void synchroneOccupied()
        {
            Matrix3D tt = new Matrix3D();
            Matrix3D ss = new Matrix3D();

            foreach (IModel t in models)
            {
                tt = t.getElement().Transform.Value;
                foreach (IModel s in models)
                {
                    ss = s.getElement().Transform.Value;
                    if ((ss.OffsetX == tt.OffsetX && ss.OffsetY == tt.OffsetY) && t.Name != s.Name)
                    {
                        t.Occupied = true;
                        break;
                    }
                }
            }
        }

    }
}
