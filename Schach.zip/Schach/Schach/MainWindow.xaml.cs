﻿using System;
using System.Windows;
using System.Windows.Media;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Threading;

namespace Schach
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();
            Settings settings = new Settings();
            settings.configure(_myviewport);

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            
           MessageBoxResult result =  MessageBox.Show("Spiel beenden?", "", MessageBoxButton.YesNo);

            if(result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

    }
    public class Datacontext : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private DispatcherTimer counter1 = new DispatcherTimer();
        private DispatcherTimer counter2 = new DispatcherTimer();
        public DispatcherTimer Counter2
        {
            get
            {
                return counter2;
            }

            set
            {
                counter2 = value;
                OnPropertyChanged();
            }
        }

        public DispatcherTimer Counter1
        {
            get
            {
                return counter1;
            }

            set
            {
                counter1 = value;
                OnPropertyChanged();
            }
        }

        public void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string property = null)
        {
            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
  
}
