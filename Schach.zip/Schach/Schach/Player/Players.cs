﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace Schach
{
    public interface IPlayer
    {
        IPlayer nextPlayer();
        ChessColors Color { get; set; }
    }
    public class Player1 : IPlayer
    {
        public ChessColors Color { get { return ChessColors.BLACK; } set { } }

        Point3D cameraPosition = new Point3D(1600, 400, 1300);
        Vector3D cameraDirection = new Vector3D(-2, 0, -2);
        PerspectiveCamera Camera = new PerspectiveCamera();
        public Player1(PerspectiveCamera camera)
        {
            camera.Position = cameraPosition;
            camera.LookDirection = cameraDirection;
            camera.UpDirection = new Vector3D(0, 0, 1);
            camera.FieldOfView = 60;
            Camera = camera;
            Synchronize.syncCamera(Camera);
        }
        public IPlayer nextPlayer()
        {
            return new Player2(Camera);
        }
    }
    public class Player2 : IPlayer
    {
        Point3D cameraPosition = new Point3D(-800, 400, 1300);
        Vector3D cameraDirection = new Vector3D(2, 0, -2);
        PerspectiveCamera Camera = new PerspectiveCamera();
        public ChessColors Color { get { return ChessColors.WHITE; } set { } }
        public Player2(PerspectiveCamera camera)
        {
            camera.Position = cameraPosition;
            camera.LookDirection = cameraDirection;
            camera.UpDirection = new Vector3D(0, 0, 1);
            camera.FieldOfView = 60;
            Camera = camera;
            Synchronize.syncCamera(Camera);

        }
        public IPlayer nextPlayer()
        {
            return new Player1(Camera);
        }
    }
}
