﻿using HelixToolkit.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Media3D;

namespace Schach
{
    class Test
    {

        private List<IModel> models;
        public Test(List<IModel> models)
        {
            this.models = models;
        }
        public bool isoccupied()
        {
            Tile t = new Tile();

            if (t.Occupied)
            {
                return true;
            }
            return false;
        }
       


    }

}
