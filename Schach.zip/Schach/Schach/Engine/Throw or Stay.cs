﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schach
{
    public interface IStateThrowStay
    {
        IStateThrowStay throwFigure(IModel model);
    }
    public class StateStay : IStateThrowStay
    {
        public IStateThrowStay throwFigure(IModel model)
        {
            return new StateStay();
        }
    }
    public class StateThrow : IStateThrowStay
    {
        public IStateThrowStay throwFigure(IModel model)
        {
            Synchronize.syncGame(model);
            return new StateThrow();
        }
    }
}
