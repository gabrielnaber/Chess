﻿using System;
using System.Windows.Input;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;
using System.Collections.Generic;

namespace Schach
{
    static class Moving
    {
        private static ModelUIElement3D target;
        private static ModelUIElement3D source;
        public static List<IModel> models = Synchronize.models;
        static public IPlayer player = new Player1(new PerspectiveCamera());
        private static IModel targetModel;
        private static IModel sourceModel;
        private static List<bool> available = new List<bool>();
        public static void Move(object sender, MouseEventArgs e)
        {
            IMovementCommand command;
            ModelConverter converter;
            converter = new ModelConverter();
            ModelUIElement3D model;
            string name;
            model = sender as ModelUIElement3D;

            if (target == null)
            {
                target = model;
                name = target.GetName();

                if (name.Substring(0, 1) != "f")
                {
                    target = null;
                }

            }
            else
            {
                source = model;
                sourceModel = converter.order(source);
                targetModel = converter.order(target);

                if (targetModel.Color == player.Color)
                {
                    IAnalyzeType type = new AnalyzeDefault();
                  
                    IBuildAnalyzer buildanalyzer = type.Analyze(sourceModel, targetModel);

                    foreach (IAnalyzer i in buildanalyzer.build())
                    {

                        Matrix3D tMatrix = target.Transform.Value;
                        Matrix3D sMatrix = source.Transform.Value;

                        command = i.Analyze(tMatrix.OffsetX, tMatrix.OffsetY, sMatrix.OffsetX, sMatrix.OffsetY, target.GetName().ToString(), buildanalyzer);

                        if(command != null)
                        {
                            command.execute(sourceModel,targetModel);
                            
                        }

                    }
                }

                target = null;
                source = null;

            }
                    
                   
            }
        }
    }
